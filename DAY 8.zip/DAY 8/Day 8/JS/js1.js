    function InternalAlertJS()
    {
        document.body.style.backgroundColor="green";
        alert('Hiiiiiiiii');
    }
    function background()
    {
        document.body.style.backgroundColor="red";
    }
    function nnn()
    {
        document.getElementById("abc").style.backgroundColor="pink";
    }
    
    console.log("One of the best players in the world");