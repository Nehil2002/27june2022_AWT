$(document).ready(function(){
    $("#id1").click(function(){
        $("#ID").hide(3000);
        $(this).attr("disabled",true); 
        $("id2").attr("disabled",false);
    });


    $("#id2").click(function(){
        
        $("#ID").show(3000);
        $(this).attr("disabled",true); 
        $("#id1").attr("disabled",false);
        
    });

    $("#id3").click(function(){
        
        $("#ID").width(2000);
        $("#ID").height(300);
    });


    $("#id4").click(function(){
        $("#ID").width(200);
        $("#ID").height(30);
        
    });
});